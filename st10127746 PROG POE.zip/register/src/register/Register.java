/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package register;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */

public class Register {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        //method to prompt the user
        register_user();
        
    }
    
    //method to register the user
    private static void register_user(){
        
        //declaring variables & scanner
        Scanner input = new Scanner(System.in);
        String username, put,
                first_name,
                last_name,
                password;
        
       int m, n, i, j;
        
        //class login object 
        Login verify = new Login();
       
        
        //prompting the user
        var name =JOptionPane.showInputDialog("Enter your Name?");
        
       
        var lname =  JOptionPane.showInputDialog("Enter your Last name?");
        
        
        //do while loop
        do{
            username =JOptionPane.showInputDialog("Enter your Username");
            
            
         }while(verify.checkUserName(username)!= true);
        
       password =JOptionPane.showInputDialog("Enter your Password");
      
       
       JOptionPane.showInputDialog(PassCheck(password));
       JOptionPane.showMessageDialog(null, "Welcome to easy KanBan");
       
       // create a while loop
        while (true) {
            int option = Integer.parseInt(JOptionPane.showInputDialog(null, 
                    "Choose an option: " +"\n" +
                            "1) Add task" +"\n"+
                            "2) Show report" +"\n"+
                            "3) Quit"));
            
             while(option==1 || option ==2 || option ==3){
                  if(option==1){
                      int task = 0;
                      //declarations
        String taskName[] = new String[task];
        String taskDescription[] = new String[task];
        int[] taskNum = new int[task];
        int[] taskDuration = new int[task];
        String[] taskID = new String[task];
        String[] taskDeveloper = new String[task];
        String[] taskStatus = new String[task];
                       int tasks = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Enter the amount of tasks you will be doing"));
                       
             JOptionPane.showInputDialog(null, "Enter a task name "); // prompt the user to enter the task name
             
             put = JOptionPane.showInputDialog(null, "Enter the hours duration");  // prompt the user to enter the task duration
             m= Integer.parseInt(put);
             
             JOptionPane.showInputDialog(null, "Enter the description");// prompt the user to enter the task description
             
             JOptionPane.showInputDialog(null, "Enter developer details"); // prompt the user to enter the task developer
             
             
             int optionTwo = Integer.parseInt(JOptionPane.showInputDialog(null, 
                  "Choose a status: "+"\n"+
                          "1) To do" +"\n"
                          + "2) Done" +"\n"
                          + "3) Doing"));
             
              // creat an if statement
              if(optionTwo==1){
                   taskStatus[1] = "To do";
          }else if(optionTwo ==2){
              taskStatus[2] = "Done";
          }if(optionTwo ==3){
              taskStatus[3] = "Doing";
                  }
         
    }
             }
    }

}
                  



            
             
        
    
    
    public static String PassCheck (String Password) {

		String result = "Password successfully captured";			// Sets the initial result as valid
		int length = 0;						
		int numCount = 0;					
		int capCount = 0;					

		for (int k =0; k < Password.length(); k++) {
			if ((Password.charAt(k) >= 47 && Password.charAt(k) <= 58) || (Password.charAt(k) >= 64 && Password.charAt(k) <= 91) ||
				(Password.charAt(k) >= 97 && Password.charAt(k) <= 122)) {
					//Keep the Password
				} else {
					result = "Password Contains Invalid Character!";		//Checks that password contains only letters and numbers
				}

			if ((Password.charAt(k) > 47 && Password.charAt(k) < 58)) {			// Counts the number of numbers
				numCount ++;
			}

			if ((Password.charAt(k) > 64 && Password.charAt(k) < 91)) {			// Counts the number of capital letters
				capCount ++;
			}

			length = (k + 1);								// Counts the passwords length

		} // Ends the for loop

		if (numCount < 1){									// Checks that password contains a number
			result = "password must be:\n" +
                                 "• At least eight characters long. \n" +
                                 "• Contain a capital letter\n" +
                                 "• Contain a number\n" +
                                 "• Contain a special character";
		}

		if (capCount < 1) {									// Checks that password contains  capital letter
			result = "password must be:\n" +
                                 "• At least eight characters long. \n" +
                                 "• Contain a capital letter\n" +
                                 "• Contain a number\n" +
                                 "• Contain a special character";
		}

		if (length < 8){									// Checks that password is long enough
			result = "password must be:\n" +
                                 "• At least eight characters long. \n" +
                                 "• Contain a capital letter\n" +
                                 "• Contain a number\n" +
                                 "• Contain a special character";
		}

			return (result);
        
    
        
        
        
    }
    

    private static boolean checkPasswordComplexity(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        
    }

    

    private static void register_task() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
 }

